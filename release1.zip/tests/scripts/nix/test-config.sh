set -e

default_provider=local/v1
default_namespace=test-ns
default_project=test-project
default_application=test-application
default_stage=test-stage
default_working_dir=.

printf "\n\nUSAGE: $0 <namespace [${default_namespace}]> <project [${default_project}]> <application [${default_application}]> <stage [${default_stage}]> <working_dir [${default_working_dir}]>\n\n"

if [ $1 ]; then
  namespace="$1"
else
  namespace="${default_namespace}"
fi

if [ $2 ]; then
  project="$2"
else
  project="${default_project}"
fi

if [ $3 ]; then
  application="$3"
else
  application="${default_application}"
fi

if [ $4 ]; then
  stage="$4"
else
  stage="${default_stage}"
fi

if [ $5 ]; then
  working_dir="$5"
else
  working_dir="${default_working_dir}"
fi

if [ ! -d tests/output ]; then
    mkdir tests/output
fi

printf "\n\nmabledso config get -b5 -w \"${working_dir}\" --global\n\n"
mabledso config get -b5 -w "${working_dir}" --global > /dev/null

printf "\n\nmabledso config set -b5 -w \"${working_dir}\" test.global-config some-value --global\n\n"
mabledso config set -b5 -w "${working_dir}" test.global-config some-value -b5 --global

printf "\n\nmabledso config get -b5 -w \"${working_dir}\" test.global-config --global\n\n"
mabledso config get -b5 -w "${working_dir}" test.global-config --global > /dev/null

printf "\n\nmabledso config init -b5 -w \"${working_dir}\"\n\n"
mabledso config init -b5 -w "${working_dir}" 
printf "\n\nmabledso config get -b5 -w \"${working_dir}\" --local\n\n"
mabledso config get -b5 -w "${working_dir}" --local > /dev/null

printf "\n\nmabledso config set -b5 -w \"${working_dir}\" test.local-config mable some-value\n\n"
mabledso config set -b5 -w "${working_dir}" test.local-config some-value

printf "\n\nmabledso config get -b5 -w \"${working_dir}\" test.local-config\n\n"
mabledso config get -b5 -w "${working_dir}" test.local-config > /dev/null

printf "\n\nmabledso config unset -b5 -w \"${working_dir}\" test.global-config --global\n\n"
mabledso config unset -b5 -w "${working_dir}" test.global-config --global

printf "\n\nmabledso config unset -b5 -w \"${working_dir}\" test.local-config\n\n"
mabledso config unset -b5 -w "${working_dir}" test.local-config

printf "\n\nmabledso config set -b5 -w \"${working_dir}\" namespace ${namespace}\n\n"
mabledso config set -b5 -w "${working_dir}" namespace ${namespace}

printf "\n\nmabledso config set -b5 -w \"${working_dir}\" project ${project}\n\n"
mabledso config set -b5 -w "${working_dir}" project ${project}

printf "\n\nmabledso config set -b5 -w \"${working_dir}\" application ${application}\n\n"
mabledso config set -b5 -w "${working_dir}" application ${application}

