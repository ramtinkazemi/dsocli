set -e

default_provider=local/v1
default_namespace=test-ns
default_project=test-project
default_application=test-application
default_stage=test-stage
default_working_dir=.

printf "\n\nUSAGE: $0 <namespace [${default_namespace}]> <project [${default_project}]> <application [${default_application}]> <stage [${default_stage}]> <working_dir [${default_working_dir}]> <provider [${default_provider}]>\n\n"

if [ $1 ]; then
    namespace=$1
else
    namespace=${default_namespace}
fi

if [ $2 ]; then
    project=$2
else
    project=${default_project}
fi

if [ $3 ]; then
    application=$3
else
    application=${default_application}
fi

if [ $4 ]; then
    stage=$4
else
    stage=${default_stage}
fi

if [ $5 ]; then
    working_dir=$5
else
    working_dir=${default_working_dir}
fi

if [ $6 ]; then
    provider=$6
else
    provider=${default_provider}
fi

###################################

if [ ! -d tests/output/template ]; then
    mkdir tests/output/template
else
    rm -rf tests/output/template/*
fi

###################################

export DSO_ALLOW_STAGE_TEMPLATES=yes


###################################
### delete existing templates, in order to also test overriding configurartions, they will be set later

printf "\n\nmabledso template list -b5 -w \"${working_dir}\" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" --global-scope --uninherited | mabledso template delete -b5 -w \"${working_dir}\" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" --global-scope -i -\n\n"
mabledso template list -b5 -w "${working_dir}" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" --global-scope --uninherited | mabledso template delete -b5 -w "${working_dir}" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" --global-scope -i - > /dev/null

printf "\n\nmabledso template list -b5 -w \"${working_dir}\" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" -s ${stage} --global-scope --uninherited | mabledso template delete  -b5 -w \"${working_dir}\" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" -s ${stage} -global-scope -i -\n\n"
mabledso template list -b5 -w "${working_dir}" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" -s ${stage} --global-scope --uninherited | mabledso template delete -b5 -w "${working_dir}" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" -s ${stage} --global-scope -i -> /dev/null

printf "\n\nmabledso template list -b5 -w \"${working_dir}\" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" --project-scope --uninherited | mabledso template delete -b5 -w \"${working_dir}\" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" --project-scope -i -\n\n"
mabledso template list -b5 -w "${working_dir}" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" --project-scope --uninherited | mabledso template delete -b5 -w "${working_dir}" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" --project-scope -i - -b5 > /dev/null

printf "\n\nmabledso template list -b5 -w \"${working_dir}\" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" -s ${stage} --project-scope --uninherited -f json | mabledso template delete -b5 -w \"${working_dir}\" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" -s ${stage} --project-scope -i - -f json\n\n"
mabledso template list -b5 -w "${working_dir}" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" -s ${stage} --project-scope --uninherited -f json | mabledso template delete -b5  -w "${working_dir}" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" -s ${stage} --project-scope -i - -f json> /dev/null

printf "\n\nmabledso template list -b5 -w \"${working_dir}\" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" --uninherited -f yaml | mabledso template delete -b5 -w \"${working_dir}\" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" -i - -f yaml\n\n"
mabledso template list -b5 -w "${working_dir}" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" --uninherited -f yaml | mabledso template delete -b5 -w "${working_dir}" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" -i - -f yaml> /dev/null

printf "\n\nmabledso template list -b5 -w \"${working_dir}\" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" -s ${stage} --uninherited -f json | mabledso template delete -b5 -w \"${working_dir}\" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" -s ${stage} -i - -f json\n\n"
mabledso template list -b5 -w "${working_dir}" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" -s ${stage} --uninherited -f json | mabledso template delete -b5 -w "${working_dir}" --namespace ${namespace} --project ${project} --application ${application} --config \"template.provider.id=${provider}\" -s ${stage} -i - -f json > /dev/null


###################################
### Setting confgiurations
printf "\n\nmabledso config set -b5 -w \"${working_dir}\" namespace ${namespace}\n\n"
mabledso config set -b5 -w "${working_dir}" namespace ${namespace}

printf "\n\nmabledso config set -b5 -w \"${working_dir}\" project ${project}\n\n"
mabledso config set -b5 -w "${working_dir}" project ${project}

printf "\n\nmabledso config set -b5 -w \"${working_dir}\" application ${application}\n\n"
mabledso config set -b5 -w "${working_dir}" application ${application}

printf "\n\nmabledso config set -b5 -w \"${working_dir}\" template.provider.id \"${provider}\"\n\n"
mabledso config set -b5 -w "${working_dir}" template.provider.id "${provider}"


###################################
### add context-specific templates

printf "\n\nmabledso template add -b5 -w \"${working_dir}\" global.template -r 'tests/output/template/*' --global-scope -c tests/sample-templates/global-template\n\n"
mabledso template add -b5 -w "${working_dir}" global.template -r 'tests/output/template/*' --global-scope -c tests/sample-templates/global-template > /dev/null

printf "\n\nmabledso template add -b5 -w \"${working_dir}\" global.stage_template -r 'tests/output/template/*' -s ${stage} --global-scope -c tests/sample-templates/global-stage-template\n\n"
mabledso template add -b5 -w "${working_dir}" global.stage_template -r 'tests/output/template/*' -s ${stage} --global-scope -c tests/sample-templates/global-stage-template > /dev/null

printf "\n\nmabledso template add -b5 -w \"${working_dir}\" project.template -r 'tests/output/template/*' --project-scope -c tests/sample-templates/project-template\n\n"
mabledso template add -b5 -w "${working_dir}" project.template -r 'tests/output/template/*' --project-scope -c tests/sample-templates/project-template > /dev/null

printf "\n\nmabledso template add -b5 -w \"${working_dir}\" project.stage_template -r 'tests/output/template/*' -s ${stage} --project-scope -c tests/sample-templates/project-stage-template\n\n"
mabledso template add -b5 -w "${working_dir}" project.stage_template -r 'tests/output/template/*' -s ${stage} --project-scope -c tests/sample-templates/project-stage-template > /dev/null

printf "\n\nmabledso template add -b5 -w \"${working_dir}\" app.template -r 'tests/output/template/*' -c tests/sample-templates/app-template\n\n"
mabledso template add -b5 -w "${working_dir}" app.template -r 'tests/output/template/*' -c tests/sample-templates/app-template > /dev/null

printf "\n\nmabledso template add -b5 -w \"${working_dir}\" app.stage_template -r 'tests/output/template/*' -s ${stage} -c tests/sample-templates/app-stage-template\n\n"
mabledso template add -b5 -w "${working_dir}" app.stage_template -r 'tests/output/template/*' -s ${stage} -c tests/sample-templates/app-stage-template > /dev/null


###################################
### add overriden templates

printf "\n\nmabledso template add -b5 -w \"${working_dir}\" overriden_template -r 'tests/output/template/*' --global-scope -c tests/sample-templates/global-template-overriden\n\n"
mabledso template add -b5 -w "${working_dir}" overriden_template -r 'tests/output/template/*' --global-scope -c tests/sample-templates/global-template-overriden > /dev/null

printf "\n\nmabledso template add -b5 -w \"${working_dir}\" overriden_template -r 'tests/output/template/*' -s ${stage} --global-scope -c tests/sample-templates/global-stage-template-overriden\n\n"
mabledso template add -b5 -w "${working_dir}" overriden_template -r 'tests/output/template/*' -s ${stage} --global-scope -c tests/sample-templates/global-stage-template-overriden > /dev/null

printf "\n\nmabledso template add -b5 -w \"${working_dir}\" overriden_template -r 'tests/output/template/*' --project-scope -c tests/sample-templates/project-template-overriden\n\n"
mabledso template add -b5 -w "${working_dir}" overriden_template -r 'tests/output/template/*' --project-scope -c tests/sample-templates/project-template-overriden > /dev/null

printf "\n\nmabledso template add -b5 -w \"${working_dir}\" overriden_template -r 'tests/output/template/*' -s ${stage} --project-scope -c tests/sample-templates/project-stage-template-overriden\n\n"
mabledso template add -b5 -w "${working_dir}" overriden_template -r 'tests/output/template/*' -s ${stage} --project-scope -c tests/sample-templates/project-stage-template-overriden > /dev/null

printf "\n\nmabledso template add -b5 -w \"${working_dir}\" overriden_template -r 'tests/output/template/*' -c tests/sample-templates/app-template-overriden\n\n"
mabledso template add -b5 -w "${working_dir}" overriden_template -r 'tests/output/template/*' -c tests/sample-templates/app-template-overriden > /dev/null

printf "\n\nmabledso template add -b5 -w \"${working_dir}\" overriden_template -r 'tests/output/template/*' -s ${stage} -c tests/sample-templates/app-stage-template-overriden\n\n"
mabledso template add -b5 -w "${working_dir}" overriden_template -r 'tests/output/template/*' -s ${stage} -c tests/sample-templates/app-stage-template-overriden > /dev/null


###################################
### getting some templates

printf "\n\nmabledso template get -b5 -w \"${working_dir}\" overriden_template -f raw\n\n"
mabledso template get overriden_template -b5 -w "${working_dir}" -f raw > /dev/null

printf "\n\nmabledso template get -b5 -w \"${working_dir}\" overriden_template -s ${stage} -f raw\n\n"
mabledso template get overriden_template -b5 -w "${working_dir}" -s ${stage} -f raw > /dev/null

printf "\n\nmabledso template get -b5 -w \"${working_dir}\" app.template -s ${stage} -f raw\n\n"
mabledso template get -b5 -w "${working_dir}" app.template -s ${stage} -f raw > /dev/null

printf "\n\nmabledso template get -b5 -w \"${working_dir}\" app.stage_template -s ${stage} -f raw\n\n"
mabledso template get -b5 -w "${working_dir}" app.stage_template -s ${stage} -f raw > /dev/null


###################################
### edit some templates

printf "\n\nmabledso template edit -b5 -w \"${working_dir}\" overriden_template --global-scope\n\n"
mabledso template edit overriden_template -b5 -w "${working_dir}" --global-scope

printf "\n\nmabledso template edit -b5 -w \"${working_dir}\" overriden_template  -s ${stage} --project-scope\n\n"
mabledso template edit overriden_template -b5 -w "${working_dir}"  -s ${stage} --project-scope

printf "\n\nmabledso template edit -b5 -w \"${working_dir}\" app.template\n\n"
mabledso template edit -b5 -w "${working_dir}" app.template

printf "\n\nmabledso template edit -b5 -w \"${working_dir}\" app.stage_template -s ${stage}\n\n"
mabledso template edit -b5 -w "${working_dir}" app.stage_template -s ${stage}


###################################
### getting history of some templates

printf "\n\nmabledso template history -b5 -w \"${working_dir}\" overriden_template -f json\n\n"
mabledso template history -b5 -w "${working_dir}" overriden_template -f json -b5 > /dev/null

printf "\n\nmabledso template history -b5 -w \"${working_dir}\" overriden_template -s ${stage} -f json\n\n"
mabledso template history -b5 -w "${working_dir}" overriden_template -s ${stage} -f json -b5 > /dev/null

printf "\n\nmabledso template history -b5 -w \"${working_dir}\" app.template -s ${stage} --query-all -f json\n\n"
mabledso template history -b5 -w "${working_dir}" app.template -s ${stage} --query-all -f json -b5 > /dev/null

printf "\n\nmabledso template history -b5 -w \"${working_dir}\" app.stage_template -s ${stage} --query-all -f json\n\n"
mabledso template history -b5 -w "${working_dir}" app.stage_template -s ${stage} --query-all -f json -b5 > /dev/null


###################################
### listing some templates

printf "\n\nmabledso template list -b5 -w \"${working_dir}\" -s ${stage} --uninherited --query-all --filter overriden_template\n\n"
mabledso template list -b5 -w "${working_dir}" -s ${stage} --uninherited --query-all --filter overriden_template > /dev/null

printf "\n\nmabledso template list -b5 -w \"${working_dir}\" -s ${stage} --uninherited -c --query-all -f json\n\n"
mabledso template list -b5 -w "${working_dir}" -s ${stage} --uninherited --contents --query-all -f json > tests/output/template/app-uninherited-${provider%%/*}.json

printf "\n\nmabledso template list -b5 -w \"${working_dir}\" -s ${stage} -c --query-all -f yaml\n\n"
mabledso template list -b5 -w "${working_dir}" -s ${stage} --contents --query-all -f yaml > tests/output/template/app-all-${provider%%/*}.yaml


###################################
### rendering templates

printf "\n\nmabledso template render -b5 -w \"${working_dir}\" -s ${stage} --filter overriden_template\n\n"
mabledso template render -b5 -w "${working_dir}" -s ${stage} --filter overriden_template > /dev/null 

printf "\n\nmabledso template render -b5 -w \"${working_dir}\" -s ${stage}\n\n"
mabledso template render -b5 -w "${working_dir}" -s ${stage} > /dev/null



